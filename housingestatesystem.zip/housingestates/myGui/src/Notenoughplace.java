public class Notenoughplace extends Exception {
    public Notenoughplace(String message) {
        super(message);
    }
}
